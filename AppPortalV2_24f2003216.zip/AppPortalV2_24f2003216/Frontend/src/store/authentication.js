import { reactive } from 'vue'

// Simple reactive auth store — no Pinia/Vuex
const state = reactive({
  user: null,  // null means not authenticated; { username, role } when logged in
  loading: true
})

async function fetchMe() {
  try {
    const res = await fetch('/api/me', { credentials: 'include' })
    if (res.ok) {
      state.user = await res.json()
    } else {
      state.user = null
    }
  } catch {
    state.user = null
  } finally {
    state.loading = false
  }
}

async function login(username, password) {
  const res = await fetch('/login', {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  })
  const data = await res.json()
  if (res.ok) {
    state.user = { username: data.username, role: data.role }
  }
  return { ok: res.ok, data }
}

async function logout() {
  await fetch('/logout', { credentials: 'include' })
  state.user = null
}

export default { state, fetchMe, login, logout }
