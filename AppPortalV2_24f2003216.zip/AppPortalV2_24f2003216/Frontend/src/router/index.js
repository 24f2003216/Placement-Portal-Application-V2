import { createRouter, createWebHashHistory } from 'vue-router'
import auth from '@/store/authentication.js'

// Auth views
import LoginView from '@/views/auth/LoginView.vue'
import StudentRegisterView from '@/views/auth/StudentRegisterView.vue'
import CompanyRegisterView from '@/views/auth/CompanyRegisterView.vue'

// Admin views
import AdminDashboardView from '@/views/admin/AdminDashboardView.vue'
import AdminCompaniesView from '@/views/admin/AdminCompaniesView.vue'
import AdminStudentsView from '@/views/admin/AdminStudentsView.vue'
import AdminDrivesView from '@/views/admin/AdminDrivesView.vue'
import AdminApplicationsView from '@/views/admin/AdminApplicationsView.vue'

// Company views
import CompanyDashboardView from '@/views/company/CompanyDashboardView.vue'
import CreateDriveView from '@/views/company/CreateDriveView.vue'
import EditDriveView from '@/views/company/EditDriveView.vue'
import ApplicantsView from '@/views/company/ApplicantsView.vue'

// Student views
import StudentDashboardView from '@/views/student/StudentDashboardView.vue'
import StudentProfileView from '@/views/student/StudentProfileView.vue'
import StudentHistoryView from '@/views/student/StudentHistoryView.vue'

const routes = [
  // Auth
  { path: '/', redirect: '/login' },
  { path: '/login', component: LoginView, meta: { guestOnly: true } },
  { path: '/register/student', component: StudentRegisterView, meta: { guestOnly: true } },
  { path: '/register/company', component: CompanyRegisterView, meta: { guestOnly: true } },

  // Admin
  { path: '/admin/dashboard', component: AdminDashboardView, meta: { role: 'admin' } },
  { path: '/admin/companies', component: AdminCompaniesView, meta: { role: 'admin' } },
  { path: '/admin/students', component: AdminStudentsView, meta: { role: 'admin' } },
  { path: '/admin/drives', component: AdminDrivesView, meta: { role: 'admin' } },
  { path: '/admin/applications', component: AdminApplicationsView, meta: { role: 'admin' } },

  // Company
  { path: '/company/dashboard', component: CompanyDashboardView, meta: { role: 'company' } },
  { path: '/company/drives/create', component: CreateDriveView, meta: { role: 'company' } },
  { path: '/company/drives/edit/:id', component: EditDriveView, meta: { role: 'company' } },
  { path: '/company/applicants/:id', component: ApplicantsView, meta: { role: 'company' } },

  // Student
  { path: '/student/dashboard', component: StudentDashboardView, meta: { role: 'student' } },
  { path: '/student/profile', component: StudentProfileView, meta: { role: 'student' } },
  { path: '/student/history', component: StudentHistoryView, meta: { role: 'student' } },
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

// Navigation guard
router.beforeEach(async (to) => {
  // Wait for auth to be resolved on first load
  if (auth.state.loading) {
    await auth.fetchMe()
  }

  const user = auth.state.user

  // Guest-only pages (login, register) — redirect if already logged in
  if (to.meta.guestOnly && user) {
    if (user.role === 'admin') return '/admin/dashboard'
    if (user.role === 'company') return '/company/dashboard'
    if (user.role === 'student') return '/student/dashboard'
  }

  // Role-protected pages
  if (to.meta.role) {
    if (!user) return '/login'
    if (user.role !== to.meta.role) return '/login'
  }

  return true
})

export default router
