import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    vue(),
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  server: {
    proxy: {
      '/login': 'http://localhost:5000',
      '/logout': 'http://localhost:5000',
      '/register': 'http://localhost:5000',
      '/api': 'http://localhost:5000',
      '/admin': 'http://localhost:5000',
      '/company': 'http://localhost:5000',
      '/student': 'http://localhost:5000',
      '/static': 'http://localhost:5000',
    }
  }
})
